//package Inheritence;
//
//public class Manager extends Employee{
//	
//	private int TeamSize;
//	private String ManType;
//	private double comission;
//	public Manager(int teamSize, String manType, double comission) {
//
//		TeamSize = teamSize;
//		ManType = manType;
//		this.comission = comission;
//	}
//	public int getTeamSize() {
//		return TeamSize;
//	}
//	public void setTeamSize(int teamSize) {
//		TeamSize = teamSize;
//	}
//	public String getManType() {
//		return ManType;
//	}
//	public void setManType(String manType) {
//		ManType = manType;
//	}
//	public double getComission() {
//		return comission;
//	}
//	public void setComission(double comission) {
//		this.comission = comission;
//	}
//	
//	
//	
//
//}
