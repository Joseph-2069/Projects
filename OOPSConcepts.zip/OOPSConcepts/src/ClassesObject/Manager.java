package ClassesObject;

public class Manager {

}
