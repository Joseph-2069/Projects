package SingleInterface;

public interface Bounceable {
//	All variables are by default public static and final
//	An interface cannot contain a constructor as it can not be used to create objects... .... ..... .... ..... .. ... .. ... .. 
	int BounceFactor=2;
//	All methods by default are public and abstract
	
	int noOfBounce();
	String color();

}
