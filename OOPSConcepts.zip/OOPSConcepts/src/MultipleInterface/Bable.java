package MultipleInterface;

public interface Bable {
	void B();
}
