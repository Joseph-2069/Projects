package MultipleInterface;

public class MultipleInheritenceEx {
	public static void main(String[] args) {
		Implementations imple =new Implementations();;
		imple.A();
		imple.B();
		imple.C();
	}
}
