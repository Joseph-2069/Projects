package MultipleInterface;

public class Implementations implements Aable{

	@Override
	public void B() {
System.out.println("This is Bable");		
	}

	@Override
	public void C() {
		System.out.println("This is Cable");		
		
	}

	@Override
	public void A() {
		System.out.println("This is Aable");		
		
	}
	

	
}
