package MultipleInterface;
// when one interface implements the other interface then extends Keyword used between them
public interface Aable extends Bable,Cable{

	void A();
}
