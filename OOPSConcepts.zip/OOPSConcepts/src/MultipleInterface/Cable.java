package MultipleInterface;

public interface Cable {
	void C();
}
