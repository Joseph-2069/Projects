package com.Joseph.ProjectBean;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjectBeanApplicationTests {

	@Test
	void contextLoads() {
	}

}
